# Trabalho final de Prog1- Semestre 2022.2

Descrição :

Api para gerenciar uma clinica com as opçoes siguintes: 

- Cadastrar Medico 
- Logar com os acessos dos medicos
- Cadastrar Paciente
- Agendar consulta para paciente 
- Buscar Agendamento a partir do CPF
- Remover paciente do sistema
- Buscar paciente a partir do CPF

Tecnologia utlizada :
- Java 
- Banco de dados Mysql
- Ferramenta Netbeans


