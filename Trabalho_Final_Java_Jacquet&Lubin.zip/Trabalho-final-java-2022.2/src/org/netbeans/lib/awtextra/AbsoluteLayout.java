package org.netbeans.lib.awtextra;

public class AbsoluteLayout {

    public AbsoluteLayout() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
